import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { Heart, MapPin, Clock, User, IndianRupee, ArrowLeft } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface BookingConfirmationProps {
  onBack: () => void;
  onConfirmBooking: () => void;
  listingData: any;
}

export function BookingConfirmation({ onBack, onConfirmBooking, listingData }: BookingConfirmationProps) {
  const [quantity, setQuantity] = useState(1);
  
  const listing = listingData || {
    id: 1,
    title: "50 Rotis + Sabzi",
    provider: "College Hostel",
    image: "https://images.unsplash.com/photo-1496112026977-46268fa058c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwY3VycnklMjByaWNlfGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 25,
    servings: 50,
    freshUntil: "11:00 PM",
    location: "MG Road, Bangalore",
    type: "veg",
    provider_phone: "+91 98765 43210",
    pickup_instructions: "Enter through main gate, ask for kitchen staff"
  };

  const totalAmount = listing.price * quantity;
  const platformFee = 15;
  const packagingFee = 10;
  const finalAmount = totalAmount + platformFee + packagingFee;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Food Details */}
          <Card>
            <CardContent className="p-6">
              <div className="flex space-x-4">
                <ImageWithFallback
                  src={listing.image}
                  alt={listing.title}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="flex-1 space-y-2">
                  <h2 className="text-xl font-semibold">{listing.title}</h2>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{listing.provider}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{listing.location}</span>
                  </div>
                  <Badge className="bg-green-100 text-green-700">
                    {listing.type === 'veg' ? '🥬 Vegetarian' : '🍖 Non-Vegetarian'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Booking Details */}
          <Card>
            <CardHeader>
              <CardTitle>Booking Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Quantity</label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      -
                    </Button>
                    <span className="px-4 py-2 border rounded text-center min-w-[60px]">
                      {quantity}
                    </span>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setQuantity(Math.min(listing.servings, quantity + 1))}
                    >
                      +
                    </Button>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Price per serving</label>
                  <div className="flex items-center space-x-1 mt-1">
                    <IndianRupee className="h-4 w-4" />
                    <span className="text-lg font-semibold">{listing.price}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Fresh Until</label>
                  <div className="flex items-center space-x-1 mt-1">
                    <Clock className="h-4 w-4" />
                    <span>{listing.freshUntil}</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Provider Contact</label>
                  <p className="mt-1">{listing.provider_phone}</p>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">Pickup Instructions</label>
                <p className="mt-1 text-sm">{listing.pickup_instructions}</p>
              </div>
            </CardContent>
          </Card>

          {/* Payment Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Food Cost ({quantity} × ₹{listing.price})</span>
                <span>₹{totalAmount}</span>
              </div>
              <div className="flex justify-between">
                <span>Platform Fee</span>
                <span>₹{platformFee}</span>
              </div>
              <div className="flex justify-between">
                <span>Packaging Fee</span>
                <span>₹{packagingFee}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-semibold">
                <span>Total Amount</span>
                <span>₹{finalAmount}</span>
              </div>
            </CardContent>
          </Card>

          {/* Terms and Conditions */}
          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium mb-2">📋 Booking Terms</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Pickup must be completed before the "Fresh Until" time</li>
                <li>• Contact provider if you're running late</li>
                <li>• Bring your own containers if possible</li>
                <li>• Payment can be made via UPI, Net Banking, or Cash on Delivery</li>
                <li>• Cancellation allowed up to 30 minutes before pickup</li>
              </ul>
            </CardContent>
          </Card>

          <Button 
            onClick={onConfirmBooking}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            Confirm Booking - Pay ₹{finalAmount}
          </Button>
        </div>
      </div>
    </div>
  );
}
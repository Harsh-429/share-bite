import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Heart, Gift, DollarSign, Calendar, Award, HelpCircle, ArrowLeft, Search } from "lucide-react";

interface ParticipateAsProps {
  onBack: () => void;
  onDonateFood: () => void;
  onSellFood: () => void;
  onMyBookings: () => void;
  onCSRDashboard: () => void;
  onHelpFAQ: () => void;
  onBrowseFood?: () => void;
}

export function ParticipateAs({ 
  onBack, 
  onDonateFood, 
  onSellFood, 
  onMyBookings, 
  onCSRDashboard, 
  onHelpFAQ,
  onBrowseFood
}: ParticipateAsProps) {
  const options = [
    {
      id: "browse",
      title: "Browse Food",
      description: "Find available food near you",
      icon: Search,
      color: "bg-purple-50 border-purple-200 hover:bg-purple-100",
      iconColor: "text-purple-600",
      onClick: onBrowseFood
    },
    {
      id: "donate",
      title: "Donate Food",
      description: "Share surplus food with those in need",
      icon: Gift,
      color: "bg-green-50 border-green-200 hover:bg-green-100",
      iconColor: "text-green-600",
      onClick: onDonateFood
    },
    {
      id: "sell",
      title: "Sell at Low Price",
      description: "Sell food at affordable prices to reduce waste",
      icon: DollarSign,
      color: "bg-blue-50 border-blue-200 hover:bg-blue-100",
      iconColor: "text-blue-600",
      onClick: onSellFood
    },
    {
      id: "bookings",
      title: "My Bookings",
      description: "View and manage your food bookings",
      icon: Calendar,
      color: "bg-purple-50 border-purple-200 hover:bg-purple-100",
      iconColor: "text-purple-600",
      onClick: onMyBookings
    },
    {
      id: "csr",
      title: "CSR Dashboard",
      description: "Track your social impact and contributions",
      icon: Award,
      color: "bg-orange-50 border-orange-200 hover:bg-orange-100",
      iconColor: "text-orange-600",
      onClick: onCSRDashboard
    },
    {
      id: "help",
      title: "Help & FAQ",
      description: "Get support and find answers to your questions",
      icon: HelpCircle,
      color: "bg-gray-50 border-gray-200 hover:bg-gray-100",
      iconColor: "text-gray-600",
      onClick: onHelpFAQ
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">How would you like to participate?</CardTitle>
            <p className="text-muted-foreground mt-2">
              Choose from the options below to start making a difference
            </p>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              {options.map((option) => (
                <Card
                  key={option.id}
                  className={`cursor-pointer transition-all duration-200 ${option.color}`}
                  onClick={option.onClick}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className={`p-3 rounded-full bg-white`}>
                        <option.icon className={`h-6 w-6 ${option.iconColor}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-medium">{option.title}</h3>
                        <p className="text-muted-foreground mt-1">{option.description}</p>
                      </div>
                      <div className="text-muted-foreground">
                        →
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
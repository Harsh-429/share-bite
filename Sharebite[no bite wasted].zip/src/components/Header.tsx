import { Button } from "./ui/button";
import { Heart, Menu } from "lucide-react";

export function Header() {
  return (
    <header className="bg-white border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <Heart className="h-8 w-8 text-primary fill-current" />
            <span className="text-xl font-semibold text-primary">Share Bite</span>
          </div>
          
          <nav className="hidden md:flex space-x-6">
            <a href="#browse" className="text-muted-foreground hover:text-primary transition-colors">
              Browse Donations
            </a>
            <a href="#donate" className="text-muted-foreground hover:text-primary transition-colors">
              Donate Food
            </a>
            <a href="#about" className="text-muted-foreground hover:text-primary transition-colors">
              How It Works
            </a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="outline" className="hidden sm:flex">
              Sign In
            </Button>
            <Button>
              Get Started
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ThemeToggle } from "./ThemeToggle";
import { Users, Heart, Utensils, Award, ArrowRight, Mail, Phone } from "lucide-react";

interface LandingPageProps {
  onLogin: () => void;
  onSignUp: () => void;
}

export function LandingPage({ onLogin, onSignUp }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/20 to-secondary/30">
      {/* Header */}
      <header className="bg-background/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <Utensils className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-primary">Share Bite</h1>
                <p className="text-sm text-muted-foreground">No bite wasted</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <ThemeToggle />
              <Button variant="outline" onClick={onLogin}>
                Login
              </Button>
              <Button onClick={onSignUp}>
                Sign Up
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold text-primary leading-tight">
                  Connecting Food,
                  <span className="text-chart-1"> Building Community</span>
                </h1>
                <p className="text-lg text-muted-foreground max-w-xl">
                  Share Bite bridges the gap between food providers and those in need, 
                  ensuring no nutritious meal goes to waste while building stronger communities.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" onClick={onSignUp} className="flex items-center gap-2">
                  Get Started <ArrowRight className="h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline" onClick={onLogin}>
                  Already have an account?
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">1000+</div>
                  <div className="text-sm text-muted-foreground">Meals Shared</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">500+</div>
                  <div className="text-sm text-muted-foreground">Active Users</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">50+</div>
                  <div className="text-sm text-muted-foreground">Partner Organizations</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1710092784814-4a6f158913b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwZG9uYXRpb24lMjBjb21tdW5pdHklMjBzaGFyaW5nfGVufDF8fHx8MTc1ODQ0NDU3MXww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Food sharing community"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-4 rounded-xl shadow-lg">
                <Heart className="h-8 w-8" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary">
              How Share Bite Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our platform connects three key groups to create a sustainable food sharing ecosystem
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center space-y-4">
                <div className="bg-chart-1/10 text-chart-1 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Utensils className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Food Providers</h3>
                <p className="text-muted-foreground">
                  Restaurants, grocery stores, and individuals can donate excess food
                  or sell at reduced prices to minimize waste.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center space-y-4">
                <div className="bg-chart-2/10 text-chart-2 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Users className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Human Recipients</h3>
                <p className="text-muted-foreground">
                  Individuals and families can access affordable, nutritious meals
                  while supporting local businesses and reducing food waste.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center space-y-4">
                <div className="bg-chart-3/10 text-chart-3 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Heart className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Animal Care</h3>
                <p className="text-muted-foreground">
                  Animal shelters and pet owners can find suitable food donations
                  to care for animals in need.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-accent/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-primary">
                Our Mission: No Bite Wasted
              </h2>
              <p className="text-lg text-muted-foreground">
                Every day, millions of meals go to waste while people and animals go hungry. 
                Share Bite is changing this by creating a digital bridge between those who have 
                excess food and those who need it most.
              </p>
              <p className="text-lg text-muted-foreground">
                Built with love by the Bro Code team, we believe technology can solve real-world 
                problems and create positive social impact in our communities.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" onClick={onSignUp}>
                  Join Our Mission
                </Button>
                <Button size="lg" variant="outline">
                  Learn More
                </Button>
              </div>
            </div>

            <Card className="border-0 shadow-xl">
              <CardContent className="p-8 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-primary text-primary-foreground p-3 rounded-full">
                    <Award className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-bold">Built by Bro Code</h3>
                    <p className="text-sm text-muted-foreground">A passionate development team</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Team Leader:</span>
                    <span className="font-semibold">Harsh Chaudhary</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Project:</span>
                    <span className="font-semibold">Share Bite Platform</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Mission:</span>
                    <span className="font-semibold">No bite wasted</span>
                  </div>
                </div>

                <div className="aspect-video rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1582005450386-52b25f82d9bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwY29sbGFib3JhdGlvbiUyMGNvZGluZ3xlbnwxfHx8fDE3NTg0NDQ1NzR8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Team collaboration"
                    className="w-full h-full object-cover"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <h2 className="text-3xl lg:text-4xl font-bold">
            Ready to Make a Difference?
          </h2>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">
            Join thousands of users who are already making an impact. Whether you're 
            donating food, finding meals, or supporting animals, every action counts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              onClick={onSignUp}
              className="flex items-center gap-2"
            >
              Start Your Journey <ArrowRight className="h-4 w-4" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={onLogin}
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
            >
              Sign In
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                  <Utensils className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold">Share Bite</h3>
                  <p className="text-sm text-muted-foreground">No bite wasted</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Building bridges between food providers and recipients to create 
                a sustainable, caring community.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Contact</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>contact@sharebite.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>+1 (555) 123-BITE</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Team Bro Code</h4>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>Led by Harsh Chaudhary</p>
                <p>Passionate about social impact</p>
                <p>Making technology work for good</p>
              </div>
            </div>
          </div>

          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Share Bite by Bro Code. Made with ❤️ for the community.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
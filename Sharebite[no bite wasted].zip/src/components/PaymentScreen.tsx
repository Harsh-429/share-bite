import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Separator } from "./ui/separator";
import { Heart, CreditCard, Smartphone, Banknote, ArrowLeft, Shield } from "lucide-react";

interface PaymentScreenProps {
  onBack: () => void;
  onPaymentSuccess: () => void;
  orderData: any;
}

export function PaymentScreen({ onBack, onPaymentSuccess, orderData }: PaymentScreenProps) {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [upiId, setUpiId] = useState("");

  const handlePayment = () => {
    if (paymentMethod === "cod" || (paymentMethod === "upi" && upiId)) {
      // Mock payment processing
      setTimeout(() => {
        onPaymentSuccess();
      }, 2000);
    }
  };

  const totalAmount = orderData?.totalAmount || 150;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Order Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>50 Rotis + Sabzi</span>
                <span>₹125</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Platform Fee</span>
                <span>₹15</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Packaging</span>
                <span>₹10</span>
              </div>
              <Separator />
              <div className="flex justify-between items-center font-medium text-lg">
                <span>Total Amount</span>
                <span>₹{totalAmount}</span>
              </div>
            </CardContent>
          </Card>

          {/* Payment Methods */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>Choose Payment Method</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                {/* UPI Payment */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <RadioGroupItem value="upi" id="upi" />
                    <Label htmlFor="upi" className="cursor-pointer flex items-center space-x-2">
                      <Smartphone className="h-5 w-5 text-purple-600" />
                      <span>UPI Payment</span>
                    </Label>
                  </div>
                  {paymentMethod === "upi" && (
                    <div className="ml-6 space-y-3">
                      <div className="space-y-2">
                        <Label htmlFor="upiId">Enter UPI ID</Label>
                        <Input
                          id="upiId"
                          placeholder="yourname@paytm / yourname@phonepe"
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          required
                        />
                      </div>
                      <div className="flex space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiByeD0iNCIgZmlsbD0iIzAwQzlGRiIvPgo8cGF0aCBkPSJNMTMuMDUgN0g2Ljk1QzYuNDI1IDcgNiA3LjQyNSA2IDcuOTVWMTIuMDVDNiAxMi41NzUgNi40MjUgMTMgNi45NSAxM0gxMy4wNUMxMy41NzUgMTMgMTQgMTIuNTc1IDE0IDEyLjA1VjcuOTVDMTQgNy40MjUgMTMuNTc1IDcgMTMuMDUgN1oiIGZpbGw9IndoaXRlIi8+CjwvcGF0aD4KPC9zdmc+" alt="PayTM" className="w-5 h-5" />
                          <span>PayTM</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiByeD0iNCIgZmlsbD0iIzVGMjU5RiIvPgo8cGF0aCBkPSJNMTMuMDUgN0g2Ljk1QzYuNDI1IDcgNiA3LjQyNSA2IDcuOTVWMTIuMDVDNiAxMi41NzUgNi40MjUgMTMgNi45NSAxM0gxMy4wNUMxMy41NzUgMTMgMTQgMTIuNTc1IDE0IDEyLjA1VjcuOTVDMTQgNy40MjUgMTMuNTc1IDcgMTMuMDUgN1oiIGZpbGw9IndoaXRlIi8+CjwvcGF0aD4KPC9zdmc+" alt="PhonePe" className="w-5 h-5" />
                          <span>PhonePe</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiByeD0iNCIgZmlsbD0iI0ZGNjAwMCIvPgo8cGF0aCBkPSJNMTMuMDUgN0g2Ljk1QzYuNDI1IDcgNiA3LjQyNSA2IDcuOTVWMTIuMDVDNiAxMi41NzUgNi40MjUgMTMgNi45NSAxM0gxMy4wNUMxMy41NzUgMTMgMTQgMTIuNTc1IDE0IDEyLjA1VjcuOTVDMTQgNy40MjUgMTMuNTc1ID7IDEzLjA1IDdaIiBmaWxsPSJ3aGl0ZSIvPgo8L3BhdGg+Cjwvc3ZnPg==" alt="GPay" className="w-5 h-5" />
                          <span>GPay</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Net Banking */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="netbanking" id="netbanking" />
                    <Label htmlFor="netbanking" className="cursor-pointer flex items-center space-x-2">
                      <CreditCard className="h-5 w-5 text-blue-600" />
                      <span>Net Banking</span>
                    </Label>
                  </div>
                </div>

                {/* Cash on Delivery */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <RadioGroupItem value="cod" id="cod" />
                    <Label htmlFor="cod" className="cursor-pointer flex items-center space-x-2">
                      <Banknote className="h-5 w-5 text-green-600" />
                      <span>Cash on Delivery (COD)</span>
                    </Label>
                  </div>
                  {paymentMethod === "cod" && (
                    <p className="ml-6 text-sm text-muted-foreground">
                      Pay ₹{totalAmount} in cash when you collect your order
                    </p>
                  )}
                </div>
              </RadioGroup>

              {/* Security Note */}
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-green-900">Secure Payment</span>
                </div>
                <p className="text-sm text-green-800">
                  Your payment information is encrypted and secure. We never store your payment details.
                </p>
              </div>

              <Button 
                onClick={handlePayment}
                disabled={!paymentMethod || (paymentMethod === "upi" && !upiId)}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-muted disabled:text-muted-foreground"
              >
                {paymentMethod === "cod" ? "Confirm Order" : `Pay ₹${totalAmount}`}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Textarea } from "./ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Heart, Star, ArrowLeft, ThumbsUp, MessageCircle } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface RatingsPageProps {
  onBack: () => void;
  bookingData?: any;
}

export function RatingsPage({ onBack, bookingData }: RatingsPageProps) {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState("");
  const [showReviews, setShowReviews] = useState(false);

  const booking = bookingData || {
    id: "BK123456",
    title: "50 Rotis + Sabzi",
    provider: "College Hostel",
    provider_image: "",
    amount: 150,
    quantity: 1
  };

  const handleSubmitRating = () => {
    if (rating > 0) {
      // Mock rating submission
      alert(`Thank you for rating ${rating} stars!`);
      onBack();
    }
  };

  const existingReviews = [
    {
      id: 1,
      user: "Priya S.",
      rating: 5,
      comment: "Excellent food quality and very fresh! The rotis were soft and the sabzi was delicious.",
      date: "2 days ago",
      helpful: 12
    },
    {
      id: 2,
      user: "Rahul M.",
      rating: 4,
      comment: "Good value for money. Food was tasty and the pickup was smooth.",
      date: "1 week ago",
      helpful: 8
    },
    {
      id: 3,
      user: "Anjali K.",
      rating: 5,
      comment: "Amazing initiative! Food was fresh and the provider was very helpful.",
      date: "2 weeks ago",
      helpful: 15
    }
  ];

  const ratingLabels = {
    1: "Poor",
    2: "Fair", 
    3: "Good",
    4: "Very Good",
    5: "Excellent"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Booking Summary */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1496112026977-46268fa058c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwY3VycnklMjByaWNlfGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt={booking.title}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h2 className="text-lg font-semibold">{booking.title}</h2>
                  <p className="text-muted-foreground">from {booking.provider}</p>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-sm text-muted-foreground">Qty: {booking.quantity}</span>
                    <span className="text-sm text-muted-foreground">₹{booking.amount}</span>
                    <Badge className="bg-green-100 text-green-700">Completed</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rating Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Rate Your Experience</CardTitle>
              <p className="text-center text-muted-foreground">
                How was your food pickup experience?
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Star Rating */}
              <div className="text-center space-y-4">
                <div className="flex justify-center space-x-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      className="transition-all duration-200 hover:scale-110"
                    >
                      <Star
                        className={`h-12 w-12 ${
                          star <= rating
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300 hover:text-yellow-300"
                        }`}
                      />
                    </button>
                  ))}
                </div>
                {rating > 0 && (
                  <p className="text-lg font-medium text-yellow-600">
                    {ratingLabels[rating as keyof typeof ratingLabels]}
                  </p>
                )}
              </div>

              {/* Written Review */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Write a Review (Optional)</label>
                <Textarea
                  placeholder="Share your experience to help other community members..."
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  rows={4}
                />
              </div>

              {/* Rating Categories */}
              {rating > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Rate specific aspects:</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <span className="text-sm">Food Quality</span>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <span className="text-sm">Pickup Experience</span>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <span className="text-sm">Value for Money</span>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <span className="text-sm">Provider Interaction</span>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <Button
                onClick={handleSubmitRating}
                disabled={rating === 0}
                className="w-full bg-yellow-600 hover:bg-yellow-700 disabled:bg-muted disabled:text-muted-foreground"
              >
                Submit Rating
              </Button>
            </CardContent>
          </Card>

          {/* Other Reviews */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Community Reviews</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowReviews(!showReviews)}
                >
                  {showReviews ? "Hide" : "View All"} Reviews
                </Button>
              </div>
            </CardHeader>
            {showReviews && (
              <CardContent className="space-y-4">
                {existingReviews.map((review) => (
                  <div key={review.id} className="border-b border-border pb-4 last:border-b-0">
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-blue-100 text-blue-700">
                          {review.user.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{review.user}</p>
                            <div className="flex items-center space-x-2">
                              <div className="flex space-x-1">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    className={`h-4 w-4 ${
                                      star <= review.rating
                                        ? "fill-yellow-400 text-yellow-400"
                                        : "text-gray-300"
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-muted-foreground">{review.date}</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-sm">{review.comment}</p>
                        <div className="flex items-center space-x-4">
                          <Button variant="ghost" size="sm" className="h-8">
                            <ThumbsUp className="h-4 w-4 mr-1" />
                            Helpful ({review.helpful})
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8">
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
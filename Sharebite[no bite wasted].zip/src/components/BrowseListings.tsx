import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Heart, Search, MapPin, Clock, Star, Users, Filter, ArrowLeft, ShoppingCart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface BrowseListingsProps {
  onBack: () => void;
  onViewDetails: (listing: any) => void;
}

export function BrowseListings({ onBack, onViewDetails }: BrowseListingsProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [cartItems, setCartItems] = useState<any[]>([]);

  const mockListings = [
    {
      id: 1,
      title: "50 Rotis + Sabzi",
      provider: "College Hostel",
      image: "https://images.unsplash.com/photo-1496112026977-46268fa058c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwY3VycnklMjByaWNlfGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 25,
      originalPrice: 40,
      servings: 50,
      freshUntil: "11:00 PM",
      rating: 5,
      location: "MG Road, Bangalore",
      distance: "0.8 km",
      type: "veg",
      urgency: "normal"
    },
    {
      id: 2,
      title: "Biryani & Raita",
      provider: "Spice Kitchen",
      image: "https://images.unsplash.com/photo-1563379091339-03246963d551?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ5YW5pJTIwaW5kaWFufGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 45,
      originalPrice: 80,
      servings: 30,
      freshUntil: "10:30 PM",
      rating: 4,
      location: "Koramangala, Bangalore",
      distance: "1.2 km",
      type: "non-veg",
      urgency: "urgent"
    },
    {
      id: 3,
      title: "South Indian Thali",
      provider: "Community Kitchen",
      image: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb3V0aCUyMGluZGlhbiUyMHRoYWxpfGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 35,
      originalPrice: 60,
      servings: 25,
      freshUntil: "9:00 PM",
      rating: 5,
      location: "Indiranagar, Bangalore",
      distance: "2.1 km",
      type: "veg",
      urgency: "normal"
    }
  ];

  const addToCart = (listing: any) => {
    setCartItems([...cartItems, listing]);
  };

  const getUrgencyColor = (urgency: string) => {
    switch(urgency) {
      case "urgent": return "bg-red-100 text-red-700";
      case "normal": return "bg-yellow-100 text-yellow-700";
      default: return "bg-green-100 text-green-700";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Button variant="ghost" onClick={onBack} className="mr-4">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-green-600 fill-current" />
                <span className="text-xl font-semibold text-primary">Share Bite</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Button variant="outline" size="icon">
                  <ShoppingCart className="h-5 w-5" />
                </Button>
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Search and Filters */}
        <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search for food, location, or provider..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Featured Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Available Near You</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockListings.map((listing) => (
              <Card key={listing.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="relative">
                  <ImageWithFallback
                    src={listing.image}
                    alt={listing.title}
                    className="w-full h-48 object-cover"
                  />
                  <Badge 
                    className={`absolute top-3 left-3 ${getUrgencyColor(listing.urgency)}`}
                  >
                    {listing.urgency === 'urgent' ? '🔴 Urgent' : listing.urgency === 'normal' ? '🟡 Normal' : '🟢 Regular'}
                  </Badge>
                  <Badge className="absolute top-3 right-3 bg-green-600">
                    {listing.type === 'veg' ? '🥬 Veg' : listing.type === 'non-veg' ? '🍖 Non-Veg' : '🌱 Vegan'}
                  </Badge>
                </div>
                
                <CardContent className="p-4 space-y-3">
                  <div>
                    <h3 className="font-medium text-lg">{listing.title}</h3>
                    <p className="text-sm text-muted-foreground">by {listing.provider}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-lg">₹{listing.price}</span>
                      <span className="text-sm text-muted-foreground line-through">₹{listing.originalPrice}</span>
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                        {Math.round((1 - listing.price/listing.originalPrice) * 100)}% off
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{listing.servings} servings</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>Fresh until {listing.freshUntil}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < listing.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">({listing.rating})</span>
                    </div>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{listing.distance}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => onViewDetails(listing)}
                    >
                      View Details
                    </Button>
                    <Button 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => addToCart(listing)}
                    >
                      Add to Cart
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Filters */}
        <div className="mb-6">
          <h3 className="font-medium mb-3">Quick Filters</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              🥬 Vegetarian Only
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              🔴 Urgent Pickups
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              💰 Under ₹30
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              📍 Within 1km
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              ⭐ High Rated
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
}
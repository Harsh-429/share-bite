import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Heart, 
  Award, 
  Download, 
  TrendingUp, 
  Users, 
  Utensils, 
  IndianRupee,
  ArrowLeft,
  Calendar,
  Target,
  Star
} from "lucide-react";

interface CSRDashboardProps {
  onBack: () => void;
}

export function CSRDashboard({ onBack }: CSRDashboardProps) {
  const stats = {
    mealsDonated: 156,
    mealsSold: 89,
    totalImpact: 245,
    amountSaved: 12450,
    carbonFootprintReduced: 234,
    peopleHelped: 178
  };

  const badges = [
    { id: 1, name: "Food Hero", icon: "🦸", description: "Donated 100+ meals", earned: true, level: 3 },
    { id: 2, name: "Community Champion", icon: "🏆", description: "Top contributor this month", earned: true, level: 2 },
    { id: 3, name: "Eco Warrior", icon: "🌱", description: "Reduced 200kg CO2", earned: true, level: 1 },
    { id: 4, name: "Sharing Star", icon: "⭐", description: "5-star average rating", earned: true, level: 2 },
    { id: 5, name: "Waste Reducer", icon: "♻️", description: "Prevented 50kg food waste", earned: false, level: 1 },
    { id: 6, name: "Bulk Seller", icon: "📦", description: "Sold 500+ meals", earned: false, level: 1 }
  ];

  const achievements = [
    { month: "January", donations: 45, sales: 23 },
    { month: "February", donations: 52, sales: 31 },
    { month: "March", donations: 59, sales: 35 }
  ];

  const nextGoals = [
    { title: "Reach 200 donations", current: 156, target: 200, reward: "Super Hero Badge" },
    { title: "Achieve 100 sales", current: 89, target: 100, reward: "Sales Champion Badge" },
    { title: "Help 200 people", current: 178, target: 200, reward: "Community Leader Badge" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Button variant="ghost" onClick={onBack} className="mr-4">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-green-600 fill-current" />
                <span className="text-xl font-semibold text-primary">Share Bite</span>
              </div>
            </div>
            <Button className="bg-orange-600 hover:bg-orange-700">
              <Download className="h-4 w-4 mr-2" />
              Download Certificate
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-4">Your CSR Impact Dashboard</h1>
          <p className="text-lg text-muted-foreground">
            Track your social responsibility contributions and community impact
          </p>
        </div>

        {/* Key Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center border-l-4 border-l-green-500">
            <CardContent className="p-6">
              <Utensils className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-600">{stats.mealsDonated}</div>
              <div className="text-sm text-muted-foreground">Meals Donated</div>
            </CardContent>
          </Card>
          
          <Card className="text-center border-l-4 border-l-blue-500">
            <CardContent className="p-6">
              <IndianRupee className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">{stats.mealsSold}</div>
              <div className="text-sm text-muted-foreground">Meals Sold</div>
            </CardContent>
          </Card>
          
          <Card className="text-center border-l-4 border-l-purple-500">
            <CardContent className="p-6">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-600">{stats.peopleHelped}</div>
              <div className="text-sm text-muted-foreground">People Helped</div>
            </CardContent>
          </Card>
          
          <Card className="text-center border-l-4 border-l-orange-500">
            <CardContent className="p-6">
              <Award className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-600">{badges.filter(b => b.earned).length}</div>
              <div className="text-sm text-muted-foreground">Badges Earned</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Impact Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Impact Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-2">🌍 Environmental Impact</h4>
                  <ul className="space-y-1 text-sm text-green-800">
                    <li>• {stats.carbonFootprintReduced}kg CO2 emissions reduced</li>
                    <li>• 1,250 liters of water saved</li>
                    <li>• 89kg of food waste prevented</li>
                  </ul>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">💰 Economic Impact</h4>
                  <ul className="space-y-1 text-sm text-blue-800">
                    <li>• ₹{stats.amountSaved.toLocaleString()} saved by community</li>
                    <li>• ₹2,225 earned through sales</li>
                    <li>• 15% reduction in food costs for recipients</li>
                  </ul>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-medium text-purple-900 mb-2">🤝 Social Impact</h4>
                  <ul className="space-y-1 text-sm text-purple-800">
                    <li>• {stats.peopleHelped} people directly helped</li>
                    <li>• 12 families regularly supported</li>
                    <li>• 8 community connections made</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Monthly Progress</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.map((month, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{month.month}</span>
                        <span className="text-sm text-muted-foreground">
                          {month.donations + month.sales} total contributions
                        </span>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Donations</span>
                          <span>{month.donations}</span>
                        </div>
                        <Progress value={(month.donations / 60) * 100} className="h-2" />
                        <div className="flex justify-between text-sm">
                          <span>Sales</span>
                          <span>{month.sales}</span>
                        </div>
                        <Progress value={(month.sales / 40) * 100} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Badges and Achievements */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5" />
                  <span>Badges Earned</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {badges.map((badge) => (
                    <div
                      key={badge.id}
                      className={`p-4 rounded-lg border-2 text-center ${
                        badge.earned
                          ? "bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300"
                          : "bg-gray-50 border-gray-200 opacity-60"
                      }`}
                    >
                      <div className="text-3xl mb-2">{badge.icon}</div>
                      <h4 className="font-medium text-sm">{badge.name}</h4>
                      <p className="text-xs text-muted-foreground mt-1">{badge.description}</p>
                      {badge.earned && (
                        <Badge className="mt-2 bg-yellow-100 text-yellow-800">
                          Level {badge.level}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Next Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Next Goals</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {nextGoals.map((goal, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-sm">{goal.title}</span>
                      <span className="text-xs text-muted-foreground">
                        {goal.current}/{goal.target}
                      </span>
                    </div>
                    <Progress value={(goal.current / goal.target) * 100} className="h-2" />
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-xs text-muted-foreground">Reward: {goal.reward}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Certificate Section */}
            <Card className="bg-gradient-to-br from-orange-100 to-yellow-100 border-orange-200">
              <CardContent className="p-6 text-center">
                <Award className="h-12 w-12 text-orange-600 mx-auto mb-3" />
                <h3 className="font-semibold text-orange-900 mb-2">Recognition Certificate</h3>
                <p className="text-sm text-orange-800 mb-4">
                  Download your official Share Bite CSR Impact Certificate
                </p>
                <Button className="bg-orange-600 hover:bg-orange-700">
                  <Download className="h-4 w-4 mr-2" />
                  Download Certificate
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
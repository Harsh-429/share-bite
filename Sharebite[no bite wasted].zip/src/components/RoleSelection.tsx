import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ThemeToggle } from "./ThemeToggle";
import { Heart, Store, Users, Cat } from "lucide-react";

interface RoleSelectionProps {
  onRoleSelect: (role: string) => void;
}

export function RoleSelection({ onRoleSelect }: RoleSelectionProps) {
  const [selectedRole, setSelectedRole] = useState<string>("");

  const roles = [
    {
      id: "provider",
      title: "Provider",
      description: "I want to donate surplus food from my restaurant, bakery, or home",
      icon: Store,
      color: "bg-chart-1/10 border-chart-1/30 text-chart-1",
      iconColor: "text-chart-1"
    },
    {
      id: "human-receiver",
      title: "Human Receiver",
      description: "I want to receive food donations for myself, family, or community",
      icon: Users,
      color: "bg-chart-2/10 border-chart-2/30 text-chart-2",
      iconColor: "text-chart-2"
    },
    {
      id: "animal-receiver",
      title: "Animal Receiver",
      description: "I want to receive food donations for animal shelters or wildlife care",
      icon: Cat,
      color: "bg-chart-3/10 border-chart-3/30 text-chart-3",
      iconColor: "text-chart-3"
    }
  ];

  const handleContinue = () => {
    if (selectedRole) {
      onRoleSelect(selectedRole);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-accent/20 to-secondary/30 flex items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Heart className="h-8 w-8 text-chart-1 fill-current" />
            <span className="text-2xl font-semibold text-primary">Share Bite</span>
          </div>
          <div>
            <CardTitle className="text-2xl">Choose Your Role</CardTitle>
            <p className="text-muted-foreground mt-2">
              Select how you'd like to participate in our food sharing community
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="grid gap-4">
            {roles.map((role) => (
              <Card
                key={role.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                  selectedRole === role.id
                    ? `${role.color} ring-2 ring-offset-2 ring-current`
                    : "border-border hover:border-muted-foreground"
                }`}
                onClick={() => setSelectedRole(role.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-full ${role.color}`}>
                      <role.icon className={`h-6 w-6 ${role.iconColor}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium">{role.title}</h3>
                      <p className="text-muted-foreground mt-1">{role.description}</p>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 ${
                      selectedRole === role.id
                        ? "bg-current border-current"
                        : "border-muted-foreground"
                    }`}>
                      {selectedRole === role.id && (
                        <div className="w-full h-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="space-y-4 pt-4">
            <Button 
              onClick={handleContinue}
              disabled={!selectedRole}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-muted disabled:text-muted-foreground"
            >
              Continue
            </Button>
            
            <p className="text-xs text-muted-foreground text-center">
              You can always update your role preferences later in your profile settings
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Heart, ArrowLeft } from "lucide-react";

interface OTPVerificationProps {
  email: string;
  mobile: string;
  onVerify: () => void;
  onBack: () => void;
}

export function OTPVerification({ email, mobile, onVerify, onBack }: OTPVerificationProps) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [timeLeft]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Auto-focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        if (nextInput) nextInput.focus();
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      if (prevInput) prevInput.focus();
    }
  };

  const handleVerify = () => {
    const otpString = otp.join("");
    if (otpString.length === 6) {
      // Mock verification - in real app would validate with backend
      onVerify();
    }
  };

  const handleResend = () => {
    setTimeLeft(60);
    setCanResend(false);
    setOtp(["", "", "", "", "", ""]);
    // Mock resend OTP
    console.log("OTP resent");
  };

  const maskedEmail = email.replace(/(.{2})(.*)(@.*)/, "$1***$3");
  const maskedMobile = mobile.replace(/(.{3})(.*)(.{4})/, "$1***$3");

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 left-4"
            onClick={onBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center justify-center space-x-2">
            <Heart className="h-8 w-8 text-green-600 fill-current" />
            <span className="text-2xl font-semibold text-primary">Share Bite</span>
          </div>
          <div>
            <CardTitle className="text-2xl">Verify Your Account</CardTitle>
            <p className="text-muted-foreground mt-2">
              We've sent a 6-digit code to your email and mobile number
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Code sent to:
            </p>
            <div className="space-y-1">
              <p className="text-sm font-medium">{maskedEmail}</p>
              <p className="text-sm font-medium">{maskedMobile}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-center space-x-2">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  id={`otp-${index}`}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-12 h-12 text-center text-lg font-medium border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent"
                />
              ))}
            </div>

            <Button 
              onClick={handleVerify}
              disabled={otp.join("").length !== 6}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-muted disabled:text-muted-foreground"
            >
              Verify
            </Button>
          </div>

          <div className="text-center space-y-2">
            {!canResend ? (
              <p className="text-sm text-muted-foreground">
                Resend code in {timeLeft} seconds
              </p>
            ) : (
              <Button
                variant="link"
                onClick={handleResend}
                className="text-green-600 hover:text-green-700"
              >
                Resend Code
              </Button>
            )}
          </div>

          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Didn't receive the code? Check your spam folder or try resending
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
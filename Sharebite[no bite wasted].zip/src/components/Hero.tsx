import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-green-50 to-blue-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl text-primary">
                Share Food,
                <br />
                <span className="text-green-600">Share Love</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-xl">
                Connect with your community to reduce food waste and help those in need. 
                Every shared meal creates a stronger, more caring neighborhood.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Start Donating
              </Button>
              <Button variant="outline" size="lg">
                Find Food Near Me
              </Button>
            </div>
            
            <div className="flex items-center space-x-8 text-sm text-muted-foreground">
              <div>
                <div className="text-2xl text-primary">2,500+</div>
                <div>Meals Shared</div>
              </div>
              <div>
                <div className="text-2xl text-primary">850+</div>
                <div>Active Donors</div>
              </div>
              <div>
                <div className="text-2xl text-primary">15</div>
                <div>Cities</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1593113630400-ea4288922497?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwZG9uYXRpb24lMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1ODQzMzM5Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Food donation volunteers"
              className="w-full h-[400px] object-cover rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 text-xl">🍎</span>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Available nearby</div>
                  <div>Fresh produce & more</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
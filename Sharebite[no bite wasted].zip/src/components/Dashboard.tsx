import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ThemeToggle } from "./ThemeToggle";
import { 
  Heart, 
  Bell, 
  Settings, 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  TrendingUp,
  Users,
  Package,
  Calendar,
  Award,
  Edit,
  LogOut
} from "lucide-react";

interface DashboardProps {
  userRole: string;
  userData: any;
  onLogout: () => void;
  onParticipate?: () => void;
}

export function Dashboard({ userRole, userData, onLogout, onParticipate }: DashboardProps) {
  const [activeTab, setActiveTab] = useState("overview");

  const getRoleInfo = () => {
    switch (userRole) {
      case "provider":
        return {
          title: "Food Provider",
          color: "bg-chart-1/10 text-chart-1 border-chart-1/20",
          icon: "🏪"
        };
      case "human-receiver":
        return {
          title: "Food Receiver",
          color: "bg-chart-2/10 text-chart-2 border-chart-2/20",
          icon: "👥"
        };
      case "animal-receiver":
        return {
          title: "Animal Care Provider",
          color: "bg-chart-3/10 text-chart-3 border-chart-3/20",
          icon: "🐾"
        };
      default:
        return {
          title: "Community Member",
          color: "bg-muted text-muted-foreground",
          icon: "👤"
        };
    }
  };

  const roleInfo = getRoleInfo();

  const mockStats = {
    provider: {
      totalDonations: 24,
      foodShared: "156 lbs",
      peopleFed: 89,
      impactScore: 94
    },
    "human-receiver": {
      mealsReceived: 12,
      foodSaved: "34 lbs",
      connections: 8,
      gratitudeScore: 98
    },
    "animal-receiver": {
      donationsReceived: 18,
      animalsFed: 127,
      partnersConnected: 15,
      impactScore: 91
    }
  };

  const currentStats = mockStats[userRole as keyof typeof mockStats] || mockStats.provider;

  const mockNotifications = [
    {
      id: 1,
      type: "new_donation",
      title: "New donation available nearby",
      message: "Fresh vegetables available at Maria's Garden - 0.5 miles away",
      time: "2 hours ago",
      unread: true
    },
    {
      id: 2,
      type: "pickup_reminder",
      title: "Pickup reminder",
      message: "Don't forget to pickup your bread from Corner Bakery today",
      time: "5 hours ago",
      unread: true
    },
    {
      id: 3,
      type: "thank_you",
      title: "Thank you message",
      message: "Johnson Family sent you a thank you note for your lasagna donation",
      time: "1 day ago",
      unread: false
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-green-600 fill-current" />
                <span className="text-xl font-semibold text-primary">Share Bite</span>
              </div>
              <Badge className={roleInfo.color}>
                {roleInfo.icon} {roleInfo.title}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full"></span>
              </Button>
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5" />
              </Button>
              <Button variant="ghost" onClick={onLogout} className="text-red-600 hover:text-red-700">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="impact">Impact</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Welcome Section */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <h1 className="text-2xl font-semibold">
                      Welcome back, {userData.fullName?.split(' ')[0] || 'Friend'}! 👋
                    </h1>
                    <p className="text-muted-foreground">
                      Ready to make a difference in your community today?
                    </p>
                    {onParticipate && (
                      <Button onClick={onParticipate} className="bg-green-600 hover:bg-green-700 mt-4">
                        Participate Now
                      </Button>
                    )}
                  </div>
                  <Avatar className="h-16 w-16">
                    <AvatarImage src="" alt={userData.fullName} />
                    <AvatarFallback className="bg-green-100 text-green-700">
                      {userData.fullName?.split(' ').map((n: string) => n[0]).join('') || 'SB'}
                    </AvatarFallback>
                  </Avatar>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(currentStats).map(([key, value], index) => (
                <Card key={key}>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 bg-green-100 rounded-lg">
                        {index === 0 && <Package className="h-5 w-5 text-green-600" />}
                        {index === 1 && <TrendingUp className="h-5 w-5 text-green-600" />}
                        {index === 2 && <Users className="h-5 w-5 text-green-600" />}
                        {index === 3 && <Award className="h-5 w-5 text-green-600" />}
                      </div>
                      <div>
                        <p className="text-2xl font-semibold">{value}</p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <Calendar className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-medium">Successfully donated fresh vegetables</p>
                      <p className="text-sm text-muted-foreground">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <Users className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Connected with new community member</p>
                      <p className="text-sm text-muted-foreground">1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Profile Information</CardTitle>
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-6">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src="" alt={userData.fullName} />
                    <AvatarFallback className="bg-green-100 text-green-700 text-lg">
                      {userData.fullName?.split(' ').map((n: string) => n[0]).join('') || 'SB'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <h2 className="text-xl font-medium">{userData.fullName}</h2>
                    <Badge className={roleInfo.color}>
                      {roleInfo.icon} {roleInfo.title}
                    </Badge>
                    {userData.organization && (
                      <p className="text-muted-foreground">{userData.organization}</p>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Email</p>
                        <p className="font-medium">{userData.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Mobile</p>
                        <p className="font-medium">{userData.mobile}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-muted-foreground mt-1" />
                      <div>
                        <p className="text-sm text-muted-foreground">Address</p>
                        <p className="font-medium">{userData.address}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bio & Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Bio</h4>
                  <p className="text-muted-foreground">
                    "Sharing Every Bite That Counts"
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Food Preferences</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">Vegetarian Friendly</Badge>
                    <Badge variant="secondary">Organic Preferred</Badge>
                    <Badge variant="secondary">Allergen Conscious</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 rounded-lg border ${
                        notification.unread ? "bg-blue-50 border-blue-200" : "bg-white"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-medium">{notification.title}</h4>
                          <p className="text-sm text-muted-foreground">{notification.message}</p>
                          <p className="text-xs text-muted-foreground">{notification.time}</p>
                        </div>
                        {notification.unread && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="impact" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Impact Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-green-50 rounded-lg">
                    <div className="text-3xl font-semibold text-green-600">156</div>
                    <div className="text-sm text-muted-foreground">Pounds of food shared</div>
                  </div>
                  <div className="text-center p-6 bg-blue-50 rounded-lg">
                    <div className="text-3xl font-semibold text-blue-600">89</div>
                    <div className="text-sm text-muted-foreground">People helped</div>
                  </div>
                  <div className="text-center p-6 bg-purple-50 rounded-lg">
                    <div className="text-3xl font-semibold text-purple-600">24</div>
                    <div className="text-sm text-muted-foreground">Donations made</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Environmental Impact</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">🌱</span>
                        <div>
                          <p className="font-medium">CO2 Reduced</p>
                          <p className="text-sm text-muted-foreground">234 lbs equivalent</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">💧</span>
                        <div>
                          <p className="font-medium">Water Saved</p>
                          <p className="text-sm text-muted-foreground">1,250 gallons</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Community Recognition</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-yellow-100 text-yellow-700">🏆 Food Hero</Badge>
                    <Badge className="bg-green-100 text-green-700">🌟 Community Champion</Badge>
                    <Badge className="bg-blue-100 text-blue-700">🤝 Connector</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";
import { Badge } from "./ui/badge";
import { 
  Heart, 
  Phone, 
  MessageCircle, 
  Mail, 
  Shield, 
  CreditCard, 
  Gift,
  ArrowLeft,
  Search,
  HelpCircle,
  Clock
} from "lucide-react";

interface HelpSupportProps {
  onBack: () => void;
}

export function HelpSupport({ onBack }: HelpSupportProps) {
  const [activeSection, setActiveSection] = useState("faq");
  const [searchQuery, setSearchQuery] = useState("");
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const hygieneRules = [
    {
      title: "Food Quality Standards",
      icon: "🍽️",
      rules: [
        "Food must be freshly prepared (within 4 hours)",
        "No expired ingredients or items past best-by date",
        "Proper storage temperature maintained",
        "Clean cooking environment and utensils used"
      ]
    },
    {
      title: "Packaging & Storage",
      icon: "📦",
      rules: [
        "Use clean, food-grade containers",
        "Properly seal all containers to prevent contamination",
        "Label containers with contents and preparation time",
        "Store at appropriate temperature until pickup"
      ]
    },
    {
      title: "Personal Hygiene",
      icon: "🧼",
      rules: [
        "Wash hands thoroughly before food preparation",
        "Use clean utensils and equipment",
        "Wear clean clothes and hair covering if needed",
        "Avoid handling food when feeling unwell"
      ]
    }
  ];

  const paymentOptions = [
    {
      method: "UPI Payment",
      icon: "📱",
      description: "Pay using any UPI app like PayTM, PhonePe, GPay",
      benefits: ["Instant payment", "Secure transactions", "No additional fees"]
    },
    {
      method: "Net Banking",
      icon: "🏦",
      description: "Direct bank transfer through your online banking",
      benefits: ["All major banks supported", "Secure payment gateway", "Transaction receipt"]
    },
    {
      method: "Cash on Delivery",
      icon: "💰",
      description: "Pay in cash when you collect your food order",
      benefits: ["No online transaction needed", "Pay only after receiving food", "Exact change preferred"]
    }
  ];

  const benefits = [
    {
      category: "For Food Donors",
      icon: "🎁",
      items: [
        "Reduce food waste and environmental impact",
        "Help community members in need",
        "Earn CSR points and recognition badges",
        "Build connections with local community",
        "Tax benefits for charitable donations"
      ]
    },
    {
      category: "For Food Recipients",
      icon: "🤝",
      items: [
        "Access fresh, quality food at low prices",
        "Save money on daily meals",
        "Support local food providers",
        "Reduce food waste in your area",
        "Connect with community members"
      ]
    },
    {
      category: "For Environment",
      icon: "🌱",
      items: [
        "Significant reduction in food waste",
        "Lower carbon footprint from food production",
        "Reduced landfill waste",
        "Conservation of water and natural resources",
        "Sustainable community practices"
      ]
    }
  ];

  const faqs = [
    {
      question: "How do I ensure food safety when donating?",
      answer: "Follow our hygiene guidelines: use fresh ingredients, maintain proper storage temperature, use clean containers, and ensure food is consumed within 4 hours of preparation."
    },
    {
      question: "What payment methods are accepted?",
      answer: "We accept UPI payments, Net Banking, and Cash on Delivery. UPI is the most convenient option with instant confirmation."
    },
    {
      question: "Can I cancel my booking?",
      answer: "Yes, you can cancel your booking up to 30 minutes before the scheduled pickup time. Refunds are processed within 3-5 business days."
    },
    {
      question: "How do I track my CSR impact?",
      answer: "Visit your CSR Dashboard to see detailed statistics including meals donated, people helped, environmental impact, and badges earned."
    },
    {
      question: "What if the food quality is not as expected?",
      answer: "You can rate and review your experience. If you're unsatisfied, contact our support team for assistance and possible resolution."
    },
    {
      question: "How are food providers verified?",
      answer: "All providers go through identity verification, phone number confirmation, and community rating system to ensure reliability."
    }
  ];

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock form submission
    alert("Thank you for contacting us! We'll get back to you within 24 hours.");
    setContactForm({ name: "", email: "", subject: "", message: "" });
  };

  const sections = [
    { id: "faq", title: "FAQ", icon: HelpCircle },
    { id: "hygiene", title: "Hygiene Rules", icon: Shield },
    { id: "payment", title: "Payment Options", icon: CreditCard },
    { id: "benefits", title: "Benefits", icon: Gift },
    { id: "contact", title: "Contact Us", icon: Mail }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-4">Help & Support</h1>
          <p className="text-lg text-muted-foreground">
            Find answers to your questions and get the support you need
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <Card className="sticky top-6">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  {sections.map((section) => (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                        activeSection === section.id
                          ? "bg-green-100 text-green-700"
                          : "hover:bg-gray-100"
                      }`}
                    >
                      <section.icon className="h-5 w-5" />
                      <span>{section.title}</span>
                    </button>
                  ))}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* FAQ Section */}
            {activeSection === "faq" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <HelpCircle className="h-5 w-5" />
                    <span>Frequently Asked Questions</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <div className="relative">
                      <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search FAQs..."
                        className="pl-10"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <Accordion type="single" collapsible>
                    {faqs.map((faq, index) => (
                      <AccordionItem key={index} value={`item-${index}`}>
                        <AccordionTrigger>{faq.question}</AccordionTrigger>
                        <AccordionContent>{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            )}

            {/* Hygiene Rules Section */}
            {activeSection === "hygiene" && (
              <div className="space-y-6">
                {hygieneRules.map((category, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <span className="text-2xl">{category.icon}</span>
                        <span>{category.title}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {category.rules.map((rule, ruleIndex) => (
                          <li key={ruleIndex} className="flex items-start space-x-2">
                            <span className="text-green-600 mt-1">✓</span>
                            <span>{rule}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Payment Options Section */}
            {activeSection === "payment" && (
              <div className="space-y-6">
                {paymentOptions.map((option, index) => (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="text-3xl">{option.icon}</div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">{option.method}</h3>
                          <p className="text-muted-foreground mb-3">{option.description}</p>
                          <div className="space-y-1">
                            {option.benefits.map((benefit, benefitIndex) => (
                              <div key={benefitIndex} className="flex items-center space-x-2">
                                <span className="text-green-600">✓</span>
                                <span className="text-sm">{benefit}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Benefits Section */}
            {activeSection === "benefits" && (
              <div className="space-y-6">
                {benefits.map((category, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <span className="text-2xl">{category.icon}</span>
                        <span>{category.category}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {category.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start space-x-2">
                            <span className="text-blue-600 mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Contact Us Section */}
            {activeSection === "contact" && (
              <div className="space-y-6">
                {/* Contact Options */}
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardContent className="p-6 text-center">
                      <Phone className="h-12 w-12 text-green-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">Call Us</h3>
                      <p className="text-muted-foreground mb-4">
                        Speak directly with our support team
                      </p>
                      <Badge className="mb-2">
                        <Clock className="h-3 w-3 mr-1" />
                        24/7 Available
                      </Badge>
                      <p className="font-medium">+91 1800-SHAREBITE</p>
                      <p className="text-sm text-muted-foreground">(+91 1800-742-7324)</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6 text-center">
                      <MessageCircle className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">Live Chat</h3>
                      <p className="text-muted-foreground mb-4">
                        Get instant help from our chat support
                      </p>
                      <Badge className="mb-2">
                        <Clock className="h-3 w-3 mr-1" />
                        9 AM - 9 PM
                      </Badge>
                      <Button className="mt-2">Start Chat</Button>
                    </CardContent>
                  </Card>
                </div>

                {/* Contact Form */}
                <Card>
                  <CardHeader>
                    <CardTitle>Send us a Message</CardTitle>
                    <p className="text-muted-foreground">
                      Fill out the form below and we'll get back to you within 24 hours
                    </p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleContactSubmit} className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Name</label>
                          <Input
                            placeholder="Your full name"
                            value={contactForm.name}
                            onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Email</label>
                          <Input
                            type="email"
                            placeholder="your@email.com"
                            value={contactForm.email}
                            onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                            required
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Subject</label>
                        <Input
                          placeholder="Brief description of your issue"
                          value={contactForm.subject}
                          onChange={(e) => setContactForm({...contactForm, subject: e.target.value})}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Message</label>
                        <Textarea
                          placeholder="Please describe your question or issue in detail..."
                          rows={4}
                          value={contactForm.message}
                          onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                          required
                        />
                      </div>
                      
                      <Button type="submit" className="w-full">
                        Send Message
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { MapPin, Clock, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface DonationCardProps {
  id: string;
  title: string;
  description: string;
  image: string;
  location: string;
  timePosted: string;
  servings: number;
  category: string;
  donor: string;
  expiresIn: string;
}

export function DonationCard({
  title,
  description,
  image,
  location,
  timePosted,
  servings,
  category,
  donor,
  expiresIn
}: DonationCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <ImageWithFallback 
          src={image}
          alt={title}
          className="w-full h-48 object-cover"
        />
        <Badge className="absolute top-3 left-3 bg-green-600">
          {category}
        </Badge>
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs">
          Expires in {expiresIn}
        </div>
      </div>
      
      <CardContent className="p-4 space-y-3">
        <div>
          <h3 className="text-lg font-medium line-clamp-1">{title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{description}</p>
        </div>
        
        <div className="flex items-center text-sm text-muted-foreground space-x-4">
          <div className="flex items-center space-x-1">
            <MapPin className="h-4 w-4" />
            <span>{location}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="h-4 w-4" />
            <span>{servings} servings</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="text-sm">
            <div className="text-muted-foreground">Donated by</div>
            <div className="font-medium">{donor}</div>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{timePosted}</span>
          </div>
        </div>
        
        <Button className="w-full bg-green-600 hover:bg-green-700">
          Request Food
        </Button>
      </CardContent>
    </Card>
  );
}
import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Heart, Shield, ArrowLeft, CheckCircle } from "lucide-react";

interface HygieneCheckboxProps {
  onBack: () => void;
  onPostDonation: () => void;
  donationData: any;
}

export function HygieneCheckbox({ onBack, onPostDonation, donationData }: HygieneCheckboxProps) {
  const [checkedItems, setCheckedItems] = useState({
    quality: false,
    freshlyCooked: false,
    coveredProperly: false
  });

  const hygieneChecks = [
    {
      id: "quality",
      title: "Food Quality Assured",
      description: "The food is of good quality and safe for consumption",
      icon: "🍽️"
    },
    {
      id: "freshlyCooked",
      title: "Freshly Prepared",
      description: "The food was prepared recently and is still fresh",
      icon: "🔥"
    },
    {
      id: "coveredProperly",
      title: "Properly Covered & Stored",
      description: "Food is properly covered and stored in hygienic conditions",
      icon: "🥡"
    }
  ];

  const handleCheckChange = (id: string, checked: boolean) => {
    setCheckedItems(prev => ({ ...prev, [id]: checked }));
  };

  const allChecked = Object.values(checkedItems).every(Boolean);

  const handlePostDonation = () => {
    if (allChecked) {
      onPostDonation();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Hygiene & Safety Confirmation</CardTitle>
            <p className="text-muted-foreground">
              Please confirm that your food donation meets our hygiene standards
            </p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Donation Summary */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Donation Summary</h3>
              <div className="space-y-1 text-sm text-muted-foreground">
                <p>• Food Type: {donationData.foodType === 'veg' ? 'Vegetarian' : donationData.foodType === 'non-veg' ? 'Non-Vegetarian' : 'Vegan'}</p>
                <p>• Quantity: Serves {donationData.quantity} people</p>
                <p>• Urgency: {donationData.urgency}</p>
                {donationData.description && <p>• Description: {donationData.description}</p>}
              </div>
            </div>

            {/* Hygiene Checklist */}
            <div className="space-y-4">
              <h3 className="font-medium">Please confirm the following:</h3>
              
              {hygieneChecks.map((check) => (
                <div key={check.id} className="border rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id={check.id}
                      checked={checkedItems[check.id as keyof typeof checkedItems]}
                      onCheckedChange={(checked) => handleCheckChange(check.id, !!checked)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-lg">{check.icon}</span>
                        <Label htmlFor={check.id} className="cursor-pointer font-medium">
                          {check.title}
                        </Label>
                      </div>
                      <p className="text-sm text-muted-foreground">{check.description}</p>
                    </div>
                    {checkedItems[check.id as keyof typeof checkedItems] && (
                      <CheckCircle className="h-5 w-5 text-green-600 mt-1" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Safety Guidelines */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">🛡️ Safety Guidelines</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Food should be consumed within 4 hours of preparation</li>
                <li>• Avoid foods that have been left at room temperature for over 2 hours</li>
                <li>• Ensure all ingredients are fresh and not expired</li>
                <li>• Use clean utensils and containers for storage</li>
              </ul>
            </div>

            <div className="pt-4">
              <Button 
                onClick={handlePostDonation}
                disabled={!allChecked}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-muted disabled:text-muted-foreground"
              >
                {allChecked ? "Post Donation" : "Please confirm all hygiene checks"}
              </Button>
              
              {allChecked && (
                <p className="text-center text-sm text-green-600 mt-2">
                  ✅ All hygiene standards confirmed
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
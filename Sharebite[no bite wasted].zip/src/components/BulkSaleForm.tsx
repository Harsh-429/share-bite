import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Textarea } from "./ui/textarea";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Heart, Upload, MapPin, ArrowLeft, Camera, IndianRupee } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface BulkSaleFormProps {
  onBack: () => void;
  onNext: (data: any) => void;
}

export function BulkSaleForm({ onBack, onNext }: BulkSaleFormProps) {
  const [formData, setFormData] = useState({
    photos: [],
    foodType: "",
    quantity: "",
    price: "",
    pickupLocation: "",
    description: ""
  });

  const [photoPreview, setPhotoPreview] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.foodType && formData.quantity && formData.price && formData.pickupLocation) {
      onNext(formData);
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = () => {
    // Mock photo upload
    setPhotoPreview("https://images.unsplash.com/photo-1496112026977-46268fa058c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwY3VycnklMjByaWNlfGVufDF8fHx8MTc1ODM3MjM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={onBack} className="mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-green-600 fill-current" />
              <span className="text-xl font-semibold text-primary">Share Bite</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Bulk Food Sale</CardTitle>
            <p className="text-muted-foreground">
              Sell surplus food at affordable prices to reduce waste
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Photo Upload */}
              <div className="space-y-2">
                <Label>Upload Photo *</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6">
                  {photoPreview ? (
                    <div className="relative">
                      <ImageWithFallback 
                        src={photoPreview}
                        alt="Food preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => setPhotoPreview("")}
                      >
                        Change
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Camera className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground mb-4">
                        Take a photo or upload from gallery
                      </p>
                      <Button type="button" onClick={handlePhotoUpload} className="mb-2">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Photo
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Food Type */}
              <div className="space-y-3">
                <Label>Food Type *</Label>
                <RadioGroup 
                  value={formData.foodType} 
                  onValueChange={(value) => updateFormData("foodType", value)}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="veg" id="veg" />
                    <Label htmlFor="veg" className="cursor-pointer">🥬 Vegetarian</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="non-veg" id="non-veg" />
                    <Label htmlFor="non-veg" className="cursor-pointer">🍖 Non-Vegetarian</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="vegan" id="vegan" />
                    <Label htmlFor="vegan" className="cursor-pointer">🌱 Vegan</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Quantity and Price */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity (Serves) *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="e.g., 10 people"
                    value={formData.quantity}
                    onChange={(e) => updateFormData("quantity", e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="price">Price per serving *</Label>
                  <div className="relative">
                    <IndianRupee className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="price"
                      type="number"
                      placeholder="e.g., 25"
                      className="pl-10"
                      value={formData.price}
                      onChange={(e) => updateFormData("price", e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Food Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the food items, ingredients, and any special notes"
                  value={formData.description}
                  onChange={(e) => updateFormData("description", e.target.value)}
                />
              </div>

              {/* Pickup Location */}
              <div className="space-y-2">
                <Label htmlFor="location">Pickup Location *</Label>
                <div className="relative">
                  <MapPin className="h-5 w-5 absolute left-3 top-3 text-muted-foreground" />
                  <Textarea
                    id="location"
                    placeholder="Enter your address with landmarks"
                    className="pl-10"
                    value={formData.pickupLocation}
                    onChange={(e) => updateFormData("pickupLocation", e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Pricing Note */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">💡 Pricing Guidelines</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Keep prices affordable to help reduce food waste</li>
                  <li>• Consider the cost of ingredients and preparation time</li>
                  <li>• Typical range: ₹15-₹50 per serving depending on the meal</li>
                  <li>• Lower prices help reach more people in need</li>
                </ul>
              </div>

              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={!formData.foodType || !formData.quantity || !formData.price || !formData.pickupLocation}
                >
                  Post Bulk Sale
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
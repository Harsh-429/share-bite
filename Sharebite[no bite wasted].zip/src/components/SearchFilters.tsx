import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Search, Filter } from "lucide-react";

export function SearchFilters() {
  return (
    <div className="bg-white border-b border-border py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search by location or food type..."
              className="pl-10"
            />
          </div>
          
          <div className="flex gap-3 flex-wrap">
            <Select>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fresh-produce">Fresh Produce</SelectItem>
                <SelectItem value="prepared-meals">Prepared Meals</SelectItem>
                <SelectItem value="baked-goods">Baked Goods</SelectItem>
                <SelectItem value="pantry-items">Pantry Items</SelectItem>
                <SelectItem value="dairy">Dairy</SelectItem>
              </SelectContent>
            </Select>
            
            <Select>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Distance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Within 1 mile</SelectItem>
                <SelectItem value="5">Within 5 miles</SelectItem>
                <SelectItem value="10">Within 10 miles</SelectItem>
                <SelectItem value="25">Within 25 miles</SelectItem>
              </SelectContent>
            </Select>
            
            <Select>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Servings" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1-5">1-5 servings</SelectItem>
                <SelectItem value="6-10">6-10 servings</SelectItem>
                <SelectItem value="11-20">11-20 servings</SelectItem>
                <SelectItem value="20+">20+ servings</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
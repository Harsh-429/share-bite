import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Heart, 
  MapPin, 
  Navigation, 
  Phone, 
  MessageCircle, 
  Clock, 
  ArrowLeft,
  CheckCircle,
  Car
} from "lucide-react";

interface PickupLocationProps {
  onBack: () => void;
  onCancelBooking: () => void;
  bookingData: any;
}

export function PickupLocation({ onBack, onCancelBooking, bookingData }: PickupLocationProps) {
  const [timeRemaining, setTimeRemaining] = useState(20 * 60); // 20 minutes in seconds
  const [status, setStatus] = useState("confirmed"); // confirmed, on-the-way, arrived, completed

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const booking = bookingData || {
    id: "BK123456",
    title: "50 Rotis + Sabzi",
    provider: "College Hostel",
    provider_phone: "+91 98765 43210",
    location: "MG Road, Near Metro Station, Bangalore",
    coordinates: { lat: 12.9716, lng: 77.5946 },
    amount: 150,
    quantity: 1,
    pickup_instructions: "Enter through main gate, ask for kitchen staff at reception"
  };

  const statusInfo = {
    confirmed: { color: "bg-blue-100 text-blue-700", icon: CheckCircle, text: "Booking Confirmed" },
    "on-the-way": { color: "bg-yellow-100 text-yellow-700", icon: Car, text: "On the way" },
    arrived: { color: "bg-green-100 text-green-700", icon: MapPin, text: "Provider is ready" },
    completed: { color: "bg-green-100 text-green-700", icon: CheckCircle, text: "Pickup Complete" }
  };

  const currentStatus = statusInfo[status as keyof typeof statusInfo];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Button variant="ghost" onClick={onBack} className="mr-4">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-green-600 fill-current" />
                <span className="text-xl font-semibold text-primary">Share Bite</span>
              </div>
            </div>
            <Badge className={currentStatus.color}>
              <currentStatus.icon className="h-4 w-4 mr-1" />
              {currentStatus.text}
            </Badge>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Map Section */}
          <Card className="lg:sticky lg:top-6 h-fit">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Pickup Location</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Mock Map - In real app would integrate Google Maps */}
              <div className="bg-green-100 h-64 rounded-lg flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-green-200 to-blue-200"></div>
                <div className="relative z-10 text-center">
                  <MapPin className="h-12 w-12 text-green-600 mx-auto mb-2" />
                  <p className="font-medium">{booking.provider}</p>
                  <p className="text-sm text-muted-foreground">{booking.location}</p>
                </div>
                {/* Mock route line */}
                <div className="absolute top-1/4 left-1/4 w-1/2 h-1 bg-blue-500 transform rotate-45 opacity-70"></div>
                <div className="absolute bottom-1/4 right-1/4 w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Distance</span>
                  <span className="font-medium">0.8 km</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Estimated time</span>
                  <span className="font-medium">{formatTime(timeRemaining)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Walking time</span>
                  <span className="font-medium">8-10 minutes</span>
                </div>
              </div>

              <Button className="w-full mt-4" variant="outline">
                <Navigation className="h-4 w-4 mr-2" />
                Open in Maps
              </Button>
            </CardContent>
          </Card>

          {/* Booking Details */}
          <div className="space-y-6">
            {/* Timer Card */}
            <Card className="border-l-4 border-l-yellow-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Pickup Time Remaining</h3>
                    <p className="text-sm text-muted-foreground">Before food expires</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-yellow-600">
                      {formatTime(timeRemaining)}
                    </div>
                    <div className="text-xs text-muted-foreground">minutes</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Booking Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Booking Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Booking ID</span>
                    <span className="font-mono">{booking.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Food Item</span>
                    <span>{booking.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Provider</span>
                    <span>{booking.provider}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Quantity</span>
                    <span>{booking.quantity} serving(s)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Amount Paid</span>
                    <span className="font-medium">₹{booking.amount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Pickup Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Pickup Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm">{booking.pickup_instructions}</p>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Bring your own containers if possible</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Show this booking confirmation to provider</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Follow hygiene protocols during pickup</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Provider */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Provider</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="flex items-center space-x-2">
                    <Phone className="h-4 w-4" />
                    <span>Call Provider</span>
                  </Button>
                  <Button variant="outline" className="flex items-center space-x-2">
                    <MessageCircle className="h-4 w-4" />
                    <span>Chat</span>
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  Provider: {booking.provider_phone}
                </p>
              </CardContent>
            </Card>

            {/* Status Updates */}
            <Card>
              <CardHeader>
                <CardTitle>Status Updates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium">Booking Confirmed</p>
                      <p className="text-xs text-muted-foreground">2 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium">Payment Successful</p>
                      <p className="text-xs text-muted-foreground">2 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                    <div>
                      <p className="text-sm font-medium">Food is being prepared</p>
                      <p className="text-xs text-muted-foreground">Now</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="space-y-3">
              <Button className="w-full bg-green-600 hover:bg-green-700">
                <Clock className="h-4 w-4 mr-2" />
                I'm on my way
              </Button>
              <Button variant="outline" className="w-full" onClick={onCancelBooking}>
                Cancel Booking
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
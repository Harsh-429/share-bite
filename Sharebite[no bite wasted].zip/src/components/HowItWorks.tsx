import { Card, CardContent } from "./ui/card";
import { Upload, Search, Heart } from "lucide-react";

export function HowItWorks() {
  const steps = [
    {
      icon: Upload,
      title: "Share Your Food",
      description: "Post photos and details of surplus food you'd like to donate to the community.",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: Search,
      title: "Connect Locally",
      description: "Community members browse and find food donations in their neighborhood.",
      color: "bg-green-100 text-green-600"
    },
    {
      icon: Heart,
      title: "Make Impact",
      description: "Coordinate pickup, reduce waste, and help build stronger community connections.",
      color: "bg-purple-100 text-purple-600"
    }
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl text-primary mb-4">How Share Bite Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our simple three-step process makes it easy to share food and build community connections
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="text-center border-none shadow-lg">
              <CardContent className="pt-8 pb-8">
                <div className={`w-16 h-16 ${step.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <step.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 md:p-12">
          <div className="text-center">
            <h3 className="text-2xl text-primary mb-4">Join Our Growing Community</h3>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
              Every day, our community prevents food waste while ensuring no one goes hungry. 
              Together, we're building a more sustainable and caring neighborhood.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
              <div>
                <div className="text-3xl text-green-600">🌱</div>
                <div className="text-lg font-medium text-primary mt-2">Eco-Friendly</div>
                <div className="text-sm text-muted-foreground">Reduce food waste</div>
              </div>
              <div>
                <div className="text-3xl text-blue-600">🤝</div>
                <div className="text-lg font-medium text-primary mt-2">Community</div>
                <div className="text-sm text-muted-foreground">Build connections</div>
              </div>
              <div>
                <div className="text-3xl text-purple-600">💝</div>
                <div className="text-lg font-medium text-primary mt-2">Generosity</div>
                <div className="text-sm text-muted-foreground">Help neighbors</div>
              </div>
              <div>
                <div className="text-3xl text-orange-600">⚡</div>
                <div className="text-lg font-medium text-primary mt-2">Simple</div>
                <div className="text-sm text-muted-foreground">Easy to use</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
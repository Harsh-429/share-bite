import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Label } from "./ui/label";
import { Upload, MapPin } from "lucide-react";

export function DonationForm() {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    servings: "",
    location: "",
    contactMethod: "",
    contactInfo: "",
    pickupInstructions: "",
    expirationDate: "",
    allergens: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission - in real app this would go to backend
    alert("Thank you! Your food donation has been posted to the community.");
    setFormData({
      title: "",
      description: "",
      category: "",
      servings: "",
      location: "",
      contactMethod: "",
      contactInfo: "",
      pickupInstructions: "",
      expirationDate: "",
      allergens: ""
    });
  };

  return (
    <section id="donate" className="py-16 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl text-primary mb-4">Share Your Food</h2>
          <p className="text-lg text-muted-foreground">
            Help reduce food waste and support your community by sharing surplus food.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create Food Donation</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Food Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Fresh vegetables from garden"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select onValueChange={(value) => setFormData({...formData, category: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fresh-produce">Fresh Produce</SelectItem>
                      <SelectItem value="prepared-meals">Prepared Meals</SelectItem>
                      <SelectItem value="baked-goods">Baked Goods</SelectItem>
                      <SelectItem value="pantry-items">Pantry Items</SelectItem>
                      <SelectItem value="dairy">Dairy & Eggs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the food, its condition, and any special notes..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="servings">Number of Servings *</Label>
                  <Input
                    id="servings"
                    type="number"
                    placeholder="e.g., 4"
                    value={formData.servings}
                    onChange={(e) => setFormData({...formData, servings: e.target.value})}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="expiration">Best By Date *</Label>
                  <Input
                    id="expiration"
                    type="date"
                    value={formData.expirationDate}
                    onChange={(e) => setFormData({...formData, expirationDate: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Pickup Location *</Label>
                <div className="relative">
                  <MapPin className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="location"
                    placeholder="Enter address or neighborhood"
                    className="pl-10"
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickup">Pickup Instructions</Label>
                <Textarea
                  id="pickup"
                  placeholder="Special instructions for pickup (optional)"
                  value={formData.pickupInstructions}
                  onChange={(e) => setFormData({...formData, pickupInstructions: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="allergens">Allergens & Dietary Info</Label>
                <Input
                  id="allergens"
                  placeholder="e.g., Contains nuts, Vegetarian, Gluten-free"
                  value={formData.allergens}
                  onChange={(e) => setFormData({...formData, allergens: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label>Food Photos (Optional)</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Drag and drop photos here, or click to browse
                  </p>
                  <Button variant="outline" className="mt-2">
                    Choose Files
                  </Button>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700">
                  Post Donation
                </Button>
                <Button type="button" variant="outline" className="flex-1">
                  Save as Draft
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
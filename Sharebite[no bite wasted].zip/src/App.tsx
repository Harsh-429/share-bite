import { useState } from "react";
import { ThemeProvider } from "./components/ThemeProvider";
import { LandingPage } from "./components/LandingPage";
import { LoginPage } from "./components/LoginPage";
import { RoleSelection } from "./components/RoleSelection";
import { RegistrationForm } from "./components/RegistrationForm";
import { Dashboard } from "./components/Dashboard";
import { ParticipateAs } from "./components/ParticipateAs";
import { DonateFood } from "./components/DonateFood";
import { HygieneCheckbox } from "./components/HygieneCheckbox";
import { BulkSaleForm } from "./components/BulkSaleForm";
import { PaymentScreen } from "./components/PaymentScreen";
import { BrowseListings } from "./components/BrowseListings";
import { BookingConfirmation } from "./components/BookingConfirmation";
import { PickupLocation } from "./components/PickupLocation";
import { CSRDashboard } from "./components/CSRDashboard";
import { RatingsPage } from "./components/RatingsPage";
import { HelpSupport } from "./components/HelpSupport";

type AppState = 
  | "landing"
  | "login" 
  | "role-selection" 
  | "registration" 
  | "dashboard"
  | "participate-as"
  | "donate-food"
  | "hygiene-check"
  | "bulk-sale"
  | "payment"
  | "browse-listings"
  | "booking-confirmation"
  | "pickup-location"
  | "csr-dashboard"
  | "ratings"
  | "help-support";

export default function App() {
  const [currentState, setCurrentState] = useState<AppState>("landing");
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [userData, setUserData] = useState<any>({});
  const [isReturningUser, setIsReturningUser] = useState(false);
  const [donationData, setDonationData] = useState<any>({});
  const [saleData, setSaleData] = useState<any>({});
  const [selectedListing, setSelectedListing] = useState<any>({});
  const [bookingData, setBookingData] = useState<any>({});

  const handleGoToLogin = () => {
    setCurrentState("login");
  };

  const handleGoToSignUp = () => {
    setCurrentState("role-selection");
  };

  const handleLogin = () => {
    setCurrentState("dashboard");
    setIsReturningUser(true);
    // Mock user data for returning user
    setUserData({
      fullName: "John Smith",
      email: "john.smith@email.com",
      mobile: "+1 (555) 123-4567",
      organization: "Green Grocer",
      address: "123 Main St, San Francisco, CA 94105"
    });
    setSelectedRole("provider");
  };

  const handleSignUpStart = () => {
    setCurrentState("role-selection");
  };

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
    setCurrentState("registration");
  };

  const handleRegister = (data: any) => {
    setUserData(data);
    setCurrentState("dashboard");
  };

  const handleLogout = () => {
    setCurrentState("landing");
    setSelectedRole("");
    setUserData({});
    setIsReturningUser(false);
  };



  // Navigation handlers for new pages
  const handleParticipateAs = () => setCurrentState("participate-as");
  const handleBackToDashboard = () => setCurrentState("dashboard");
  
  const handleDonateFood = () => setCurrentState("donate-food");
  const handleSellFood = () => setCurrentState("bulk-sale");
  const handleMyBookings = () => setCurrentState("pickup-location");
  const handleCSRDashboard = () => setCurrentState("csr-dashboard");
  const handleHelpFAQ = () => setCurrentState("help-support");
  
  const handleDonateFoodNext = (data: any) => {
    setDonationData(data);
    setCurrentState("hygiene-check");
  };
  
  const handlePostDonation = () => {
    alert("Your food donation has been posted successfully!");
    setCurrentState("dashboard");
  };
  
  const handleBulkSaleNext = (data: any) => {
    setSaleData(data);
    alert("Your bulk sale has been posted successfully!");
    setCurrentState("dashboard");
  };
  
  const handleBrowseListings = () => setCurrentState("browse-listings");
  
  const handleViewDetails = (listing: any) => {
    setSelectedListing(listing);
    setCurrentState("booking-confirmation");
  };
  
  const handleConfirmBooking = () => {
    setBookingData(selectedListing);
    setCurrentState("payment");
  };
  
  const handlePaymentSuccess = () => {
    setCurrentState("pickup-location");
  };
  
  const handleCancelBooking = () => {
    alert("Booking cancelled successfully");
    setCurrentState("dashboard");
  };
  
  const handleRatings = () => setCurrentState("ratings");

  return (
    <ThemeProvider defaultTheme="dark">
      <div className="min-h-screen">
        {currentState === "landing" && (
        <LandingPage 
          onLogin={handleGoToLogin}
          onSignUp={handleGoToSignUp}
        />
      )}

      {currentState === "login" && (
        <LoginPage 
          onLogin={handleLogin}
          onSignUp={handleSignUpStart}
        />
      )}
      
      {currentState === "role-selection" && (
        <RoleSelection 
          onRoleSelect={handleRoleSelect}
        />
      )}
      
      {currentState === "registration" && (
        <RegistrationForm 
          selectedRole={selectedRole}
          onRegister={handleRegister}
        />
      )}
      
      {currentState === "dashboard" && (
        <Dashboard 
          userRole={selectedRole}
          userData={userData}
          onLogout={handleLogout}
          onParticipate={handleParticipateAs}
        />
      )}
      
      {currentState === "participate-as" && (
        <ParticipateAs
          onBack={handleBackToDashboard}
          onDonateFood={handleDonateFood}
          onSellFood={handleSellFood}
          onMyBookings={handleMyBookings}
          onCSRDashboard={handleCSRDashboard}
          onHelpFAQ={handleHelpFAQ}
          onBrowseFood={handleBrowseListings}
        />
      )}
      
      {currentState === "donate-food" && (
        <DonateFood
          onBack={() => setCurrentState("participate-as")}
          onNext={handleDonateFoodNext}
        />
      )}
      
      {currentState === "hygiene-check" && (
        <HygieneCheckbox
          onBack={() => setCurrentState("donate-food")}
          onPostDonation={handlePostDonation}
          donationData={donationData}
        />
      )}
      
      {currentState === "bulk-sale" && (
        <BulkSaleForm
          onBack={() => setCurrentState("participate-as")}
          onNext={handleBulkSaleNext}
        />
      )}
      
      {currentState === "browse-listings" && (
        <BrowseListings
          onBack={() => setCurrentState("participate-as")}
          onViewDetails={handleViewDetails}
        />
      )}
      
      {currentState === "booking-confirmation" && (
        <BookingConfirmation
          onBack={() => setCurrentState("browse-listings")}
          onConfirmBooking={handleConfirmBooking}
          listingData={selectedListing}
        />
      )}
      
      {currentState === "payment" && (
        <PaymentScreen
          onBack={() => setCurrentState("booking-confirmation")}
          onPaymentSuccess={handlePaymentSuccess}
          orderData={selectedListing}
        />
      )}
      
      {currentState === "pickup-location" && (
        <PickupLocation
          onBack={handleBackToDashboard}
          onCancelBooking={handleCancelBooking}
          bookingData={bookingData}
        />
      )}
      
      {currentState === "csr-dashboard" && (
        <CSRDashboard
          onBack={() => setCurrentState("participate-as")}
        />
      )}
      
      {currentState === "ratings" && (
        <RatingsPage
          onBack={handleBackToDashboard}
          bookingData={bookingData}
        />
      )}
      
      {currentState === "help-support" && (
        <HelpSupport
          onBack={() => setCurrentState("participate-as")}
        />
      )}
      </div>
    </ThemeProvider>
  );
}

  # Sharebite[no bite wasted]

  This is a code bundle for Sharebite[no bite wasted]. The original project is available at https://www.figma.com/design/EWwt9ROW0CQtL0uO6GPMrx/Sharebite-no-bite-wasted-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
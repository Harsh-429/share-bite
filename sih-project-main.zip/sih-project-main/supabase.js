/*
  Supabase data layer wrapper for ShareBite.
  - If window.SUPABASE_URL and window.SUPABASE_ANON_KEY are provided (via supabase.config.js),
    uses Supabase for persistence.
  - Otherwise, falls back to window.sharebiteBackend (localStorage).
*/

(function(){
  const hasCreds = typeof window.SUPABASE_URL === 'string' && typeof window.SUPABASE_ANON_KEY === 'string' && window.SUPABASE_URL && window.SUPABASE_ANON_KEY;
  let supabase = null;
  // marker for debugging which backend is used
  window.__DATA_BACKEND = hasCreds ? 'supabase' : 'local';

  async function loadSupabaseLib() {
    const cdns = [
      'https://unpkg.com/@supabase/supabase-js@2.45.4/dist/umd/supabase.js',
      'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js'
    ];
    for (const src of cdns) {
      try {
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = src;
          s.onload = resolve;
          s.onerror = reject;
          document.head.appendChild(s);
        });
        if (window.supabase) return true;
      } catch (e) {
        console.warn('[dataAPI] Failed to load Supabase from', src, e);
      }
    }
    return false;
  }

  async function ensureSupabase() {
    if (!hasCreds) {
      window.__DATA_BACKEND = 'local';
      return null;
    }
    if (supabase) return supabase;

    // Load supabase-js from CDN(s) if not already present
    if (!window.supabase) {
      const ok = await loadSupabaseLib();
      if (!ok) {
        console.warn('[dataAPI] Supabase library failed to load from all CDNs, falling back to local backend.');
        window.__DATA_BACKEND = 'local';
        return null;
      }
    }
    supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
    window.__DATA_BACKEND = 'supabase';
    console.info('[dataAPI] Using Supabase backend');
    return supabase;
  }

  function ls() {
    if (!window.sharebiteBackend) throw new Error('Local backend not available');
    return window.sharebiteBackend;
  }

  // Public API
  window.dataAPI = {
    currentBackend(){ return window.__DATA_BACKEND; },
    // POSTS
    async createFoodPost(post) {
      const sb = await ensureSupabase();
      if (!sb) return ls().createFoodPost(post);
      const payload = {
        user_id: post.userId,
        food_name: post.foodName,
        food_type: post.foodType,
        category: post.category,
        quantity: post.quantity,
        unit: post.unit,
        price_per_unit: post.pricePerUnit,
        total_amount: post.totalAmount,
        safe_until: post.safeUntil,
        description: post.description || '',
        location: post.location || '',
        status: 'available'
      };
      const { data, error } = await sb.from('food_posts').insert(payload).select('*').single();
      if (error) throw error;
      return mapPostFromRow(data);
    },

    async deleteFoodPost(postId) {
      const sb = await ensureSupabase();
      if (!sb) return ls().deleteFoodPost(postId);
      const { error } = await sb.from('food_posts').delete().eq('id', postId);
      if (error) throw error;
      return true;
    },

    async getFoodPostsByUser(userId) {
      const sb = await ensureSupabase();
      if (!sb) return ls().getFoodPostsByUser(userId);
      const { data, error } = await sb
        .from('food_posts')
        .select('*, requests:food_requests(*)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []).map(mapPostFromRowWithRequests);
    },

    async getAllFoodPosts() {
      const sb = await ensureSupabase();
      if (!sb) return ls().getAllFoodPosts();
      const { data, error } = await sb
        .from('food_posts')
        .select('*, requests:food_requests(*)')
        .eq('status', 'available')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []).map(mapPostFromRowWithRequests);
    },

    // REQUESTS
    async createRequest(req) {
      const sb = await ensureSupabase();
      if (!sb) return ls().createRequest(req);
      const payload = {
        post_id: req.postId,
        user_id: req.userId,
        quantity: req.quantity,
        message: req.message || '',
        contact: req.contact || '',
        address: req.address || '',
        status: 'pending'
      };
      const { data, error } = await sb.from('food_requests').insert(payload).select('*').single();
      if (error) throw error;
      return mapRequestFromRow(data);
    },

    async getRequestsByPost(postId) {
      const sb = await ensureSupabase();
      if (!sb) return ls().getRequestsByPost(postId);
      const { data, error } = await sb
        .from('food_requests')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []).map(mapRequestFromRow);
    },

    async getRequestsByUser(userId) {
      const sb = await ensureSupabase();
      if (!sb) return ls().getRequestsByUser ? ls().getRequestsByUser(userId) : [];
      const { data, error } = await sb
        .from('food_requests')
        .select('*, post:food_posts(*)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      // Attach post info if present
      return (data || []).map(r => {
        const base = mapRequestFromRow(r);
        if (r.post) {
          base.post = mapPostFromRow(r.post);
        }
        return base;
      });
    },

    async updateRequestStatus(requestId, status) {
      const sb = await ensureSupabase();
      if (!sb) return ls().updateRequestStatus(requestId, status);

      // 1) Read the request to get post_id and current status
      const { data: reqRow, error: getErr } = await sb
        .from('food_requests')
        .select('*')
        .eq('id', requestId)
        .single();
      if (getErr) throw getErr;
      const postId = reqRow.post_id;

      // 2) Update the request only if it is still pending (idempotent)
      const { data: updReq, error: updErr } = await sb
        .from('food_requests')
        .update({ status })
        .eq('id', requestId)
        .eq('status', 'pending')
        .select('*')
        .single();
      if (updErr) throw updErr;
      // If no row returned (already processed), return the current state
      const finalReq = updReq || reqRow;

      if (status === 'approved') {
        // 3) Mark the post as completed if it is still available
        const { error: postErr } = await sb
          .from('food_posts')
          .update({ status: 'completed' })
          .eq('id', postId)
          .eq('status', 'available');
        if (postErr) console.warn('[dataAPI] Failed to complete post on approval:', postErr);

        // 4) Reject all other pending requests for the same post
        const { error: rejectErr } = await sb
          .from('food_requests')
          .update({ status: 'rejected' })
          .eq('post_id', postId)
          .eq('status', 'pending');
        if (rejectErr) console.warn('[dataAPI] Failed to reject other requests:', rejectErr);
      }

      return mapRequestFromRow(finalReq);
    },

    async subscribeRequestsByUser(userId, onChange) {
      const sb = await ensureSupabase();
      if (!sb) {
        console.warn('[dataAPI] Realtime not available without Supabase; falling back to polling');
        return null;
      }
      const channel = sb.channel(`req_user_${userId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'food_requests', filter: `user_id=eq.${userId}` }, (payload) => {
          try { onChange && onChange(payload); } catch(e){ console.error(e); }
        })
        .subscribe((status) => {
          console.info('[dataAPI] Realtime subscription status:', status);
        });
      return channel;
    },

    async unsubscribeChannel(channel) {
      const sb = await ensureSupabase();
      if (!sb || !channel) return;
      try { await sb.removeChannel(channel); } catch(e){ console.warn('unsubscribe failed', e); }
    }
  };

  // Mappers
  function mapPostFromRow(row){
    return {
      id: row.id,
      userId: row.user_id,
      foodName: row.food_name,
      foodType: row.food_type,
      category: row.category,
      quantity: row.quantity,
      unit: row.unit,
      pricePerUnit: row.price_per_unit,
      totalAmount: row.total_amount,
      safeUntil: row.safe_until,
      description: row.description,
      location: row.location,
      status: row.status,
      views: row.views || 0,
      createdAt: row.created_at,
      requests: []
    };
  }
  function mapPostFromRowWithRequests(row){
    const p = mapPostFromRow(row);
    p.requests = Array.isArray(row.requests) ? row.requests.map(mapRequestFromRow) : [];
    return p;
  }
  function mapRequestFromRow(row){
    return {
      id: row.id,
      postId: row.post_id,
      userId: row.user_id,
      quantity: row.quantity,
      message: row.message,
      contact: row.contact,
      address: row.address,
      status: row.status,
      createdAt: row.created_at
    };
  }
})();

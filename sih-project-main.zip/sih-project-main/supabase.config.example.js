// Copy this file to supabase.config.js and fill in your project credentials
// Security: For local dev only. In production, never expose service keys in the browser.

window.SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
window.SUPABASE_ANON_KEY = 'YOUR_PUBLIC_ANON_KEY';

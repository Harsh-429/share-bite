// Supabase project credentials (public anon key only)
// NOTE: Do NOT put your service_role key in client-side code.

window.SUPABASE_URL = 'https://wfxiwqsizzbviclelgkc.supabase.co';
window.SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndmeGl3cXNpenpidmljbGVsZ2tjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg0NTAyOTgsImV4cCI6MjA3NDAyNjI5OH0.JzVSB59OKzxpEP52c2UWYg_ouFqqbxDFj2Cd5HDmBs0';
